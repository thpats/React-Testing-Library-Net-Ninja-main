import React from 'react'
import "./Banner.css"
import mountain from "../../assets/images/mountain.jpg"

export default function Banner() {
    return (
        <div className="banner" />
    )
}
